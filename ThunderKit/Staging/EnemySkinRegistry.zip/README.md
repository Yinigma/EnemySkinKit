# Info

Test mod for loading and using assets.